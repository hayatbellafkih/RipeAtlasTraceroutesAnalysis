

package preparation

import org.apache.spark.sql.SparkSession
import java.util.{ Calendar, Date }
import org.joda.time.{ DateTime, Period, DateTimeZone }
import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.apache.spark.SparkConf
import java.sql.Timestamp;
import org.apache.spark.sql.Encoders

object PrepareTraceroutes2 {

  //case class
  case class Result(
    var result: Seq[Signal],
    hop:        Int)
  case class Signal(
    rtt:  Option[Double],
    x:    Option[String],
    from: Option[String])
  case class Traceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    result:    Seq[Result])

  case class ProceedSignal(
    medianRtt: Double,
    from:      String)
  case class ProceedResult(
    var result: Seq[ProceedSignal],
    hop:        Int)
  case class MedianByHopTraceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    result:    Seq[ProceedResult])

  case class Link(
    ip1:     String,
    ip2:     String,
    rttDiff: Double)
  case class LinksTraceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    links:     Seq[Link])

  case class LinkIPs(
    ip1: String,
    ip2: String)

  case class DiffRtt(
    rtt:      Double,
    var link: LinkIPs,
    probe:    BigInt
  //msm:   Map[BigInt, Seq[BigInt]]
  )
  case class DiffRTTPeriod(
    link:   LinkIPs,
    probes: Array[BigInt],
    rtts:   Array[Double])

  case class SampleDiffRTT(
    linksDetails: DiffRTTPeriod,
    period:       Date)
  def checkSignal(signal: Signal): Boolean = {
    if (signal.x == "*")
      return false
    else if (signal.rtt == None)
      return false
    else if (signal.rtt.get <= 0) {
      return false
    } else if (javatools.Tools.isPrivateIp(signal.from.get))
      return false
    else {
      return true
    }

  }
  def removeNegative(traceroute: Traceroute): Traceroute = {

    val outerList = traceroute.result
    for (temp <- outerList) {

      val hops = temp.result
      //here we are filtering the list to only contain nonnegative elements
      val newinnerList = hops.filter(checkSignal(_))
      //here we are reassigning the newlist to result
      temp.result = newinnerList

    }
    traceroute
  }

  def medianCalculator(seq: Seq[Double]): Double = {
    //In order if you are not sure that 'seq' is sorted
    val sortedSeq = seq.sortWith(_ < _)

    if (seq.size % 2 == 1) sortedSeq(sortedSeq.size / 2)
    else {
      val (up, down) = sortedSeq.splitAt(seq.size / 2)
      (up.last + down.head) / 2
    }
  }
  def getRtts(signals: Seq[Signal]): Seq[Double] = {
    val t = signals.map(f => f.rtt.get)
    return t
  }
  def findMedianFromSignals(hop: Result): ProceedResult = {

    val signals = hop.result
    val a = signals.groupBy(_.from.get)
    val c = a map { case (from, signaux) => from -> (getRtts(signaux)) }

    val b = c.map(f => ProceedSignal(medianCalculator(f._2), f._1))

    val d = b.toSeq
    return ProceedResult(d, hop.hop)

  }
  def computeMedianRTTByhop(traceroute: Traceroute): MedianByHopTraceroute = {
    val hops = traceroute.result
    val procHops = hops.map(f => findMedianFromSignals(f))

    return MedianByHopTraceroute(traceroute.dst_name, traceroute.from, traceroute.prb_id, traceroute.msm_id, traceroute.timestamp, procHops)

  }
  def findAllLinks(firstRouter: ProceedResult, nextRouter: ProceedResult): Seq[Link] = {
    var links = Seq[Link]()

    for (currentRouter <- firstRouter.result) {
      for (prochainouter <- nextRouter.result) {
        links = links :+ Link(currentRouter.from, prochainouter.from, (currentRouter.medianRtt - prochainouter.medianRtt))
      }
    }
    println(links.toString())
    return links
  }
  def findLinksByTraceroute(spark: SparkSession, traceroute: MedianByHopTraceroute): LinksTraceroute = {
    val hops = traceroute.result
    val size = hops.size
    val s = hops.zipWithIndex
    val z = s.map {
      case (element, index) =>
        if (index + 1 < size) {
          findAllLinks(element, hops(index + 1))
        } else {
          null
        }
    }
    return new LinksTraceroute(traceroute.dst_name, traceroute.from, traceroute.prb_id, traceroute.msm_id, traceroute.timestamp, z.filter(p => p != null).flatten)
  }

  def resumeLinksTraceroute(traceroute: LinksTraceroute): Seq[DiffRtt] = {

    val links = traceroute.links
    val resumedLinks = links.map(f => DiffRtt(f.rttDiff, LinkIPs(f.ip1, f.ip2), traceroute.prb_id))
    resumedLinks
  }
  def sortLinks(diffRtt: DiffRtt): DiffRtt = {

    val link = Seq(diffRtt.link.ip1, diffRtt.link.ip2)
    val sortedLink = link.sorted

    diffRtt.link = LinkIPs(sortedLink(0), sortedLink(1))

    diffRtt
  }

  def splitStartEnd() {

  }
  def dateRange(start: DateTime, end: DateTime, step: Period): Iterator[DateTime] =
    Iterator.iterate(start)(_.plus(step)).takeWhile(!_.isAfter(end))

  def getTraceroutes(spark: SparkSession, startTimewindow: Int, endTimeWindow: Int): Seq[Traceroute] = {

    //val datasetTraceroute =
    val dataPath = getClass.getResource("/test/rttAnalysis_sample_5.json").getPath
    import spark.implicits._
    val rawtraceroutes = spark.read
      .schema(Encoders.product[Traceroute].schema)
      .json(dataPath)
      .as[Traceroute]

    println(rawtraceroutes.count())
      rawtraceroutes.toDF().show(100, truncate=false)
    val traceroutesPeriod = rawtraceroutes.filter(f => f.timestamp >0)
    
   val f= traceroutesPeriod.collect().toSeq
   f
  }

  //MAIN FUNCTION
  def main(args: Array[String]): Unit = {
    DateTimeZone.setDefault(DateTimeZone.UTC);
    val start = (new DateTime).withYear(2016)
      .withMonthOfYear(12)
      .withDayOfMonth(1)
      .withMinuteOfHour(0)
      .withHourOfDay(0)

    val end = (new DateTime).withYear(2016)
      .withMonthOfYear(12)
      .withDayOfMonth(25)
      .withMinuteOfHour(0)
      .withHourOfDay(0)
    //val rangeDates = dateRange(start, end, Period.hours(1))
    val rangeDates = Seq(1427847514, 1427849514, 1427857514)

    rangeDates.toSeq.foreach(println)

    val timewindow = 3600
    val timestamp = new Timestamp(start.getMillis()): Timestamp
    println("To timestam")
    println(timestamp)
    //val traceroutesPerPeriod = rangeDates.map(
    //  x => getTraceroutes(x, timewindow))
    
    main(start, end)

  }

  def main(startTimeWindow: DateTime, endTimeWindow: DateTime): Unit = {

    println("Préparation des traceroutes ...")

    //Create configuration
    val conf = new SparkConf().setAppName("RTT delays analysis").setMaster("local")

    //trouver le chemin vers les donnees
    val dataPath = getClass.getResource("/test/rttAnalysis_sample_5.json").getPath

    //create spark session
    val spark = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()
    import spark.implicits._

    //Chargement des traceroutes sur un case class
    println("Chargement des traceroutes sur un case class")
    val rawtraceroutes = spark.read
      .schema(Encoders.product[Traceroute].schema)
      .json(dataPath)
      .as[Traceroute]

    //Divise traceroutes per period

    val rangeDates = Seq(1427847514, 1427849514, 1427857514)
    val timewindow = 3600
    val rangeDatesTimewindows = rangeDates.map(f => (f, f + timewindow))

    val traceroutesPerPeriod = rangeDatesTimewindows.map(f => getTraceroutes(spark, f._1, f._2))
    
    traceroutesPerPeriod.toDF().show(100, truncate = false)
    

    //val traceroutesPerPeriod = rawtraceroutes.filter(x => x.timestamp > startTimewindow && x.timestamp < endTimewindow)
    //val rawtraceroutesPerPeriod =rawtrfuncaceroutes.map(func, encoder)

   // traceroutesPerPeriod.map(f)
    println("Showing 10 rows of original Dataset")
    rawtraceroutes.show(10, truncate = false)

    println("Filter failed traceroutes ... ")
    val notFailedTraceroutes = rawtraceroutes.filter(x => x.result(0).result != null)

    println("Remove invalid data  in hops")
    val cleanedTraceroutes = notFailedTraceroutes.map(x => removeNegative(x))

    println("Showing 10 rows of cleaned dataset ...")
    cleanedTraceroutes.show(10, truncate = false)

    println("Calcul de la mediane par hop (la mediane par source du signal) ...")
    val tracerouteMedianByHop = cleanedTraceroutes.map(x => computeMedianRTTByhop(x))
    tracerouteMedianByHop.show(10, truncate = false)

    println("Inference des liens par traceroute ...")
    import org.apache.spark.mllib.rdd.RDDFunctions._
    val tracerouteLinks = tracerouteMedianByHop.map(f => findLinksByTraceroute(spark, f))
    println(tracerouteLinks.show(10, truncate = false))

    val rttDiff = tracerouteLinks.map(resumeLinksTraceroute)
    val fllaten = rttDiff.collect().flatten

    val finalresult = fllaten.toSeq.toDF().show(100, truncate = false)

    val sorted = fllaten.map(f => sortLinks(f))
    sorted.toSeq.toDF().show(100, truncate = false)

    val mergedData = sorted.groupBy(_.link)
    //println( mergedData.toString())

    val resumeData = mergedData.map(f => DiffRTTPeriod(f._1, f._2.map(_.probe), f._2.map(_.rtt)))
    resumeData.toSeq.toDF().show(100, truncate = false)

  }
}