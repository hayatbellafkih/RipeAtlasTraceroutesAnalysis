package preparation

import org.apache.spark.sql.SparkSession
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.apache.spark.SparkConf
import org.apache.spark.sql.Encoders

object prepareTraceroutes_ {

  //case class



  case class Result(
    var result: Seq[Signal],
    hop:        Int)
  case class Signal(
    rtt:  Option[Double],
    x:    Option[String],
    from: Option[String])
  case class Traceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    result:    Seq[Result])
  def main(args: Array[String]): Unit = {

    println("Préparation des traceroutes ...")

    //Create configuration
    val conf = new SparkConf().setAppName("RTT delays analysis").setMaster("local")

    //trouver le chemin vers les donnees
    val dataPath = getClass.getResource("/test/rttAnalysis_sample_5.json").getPath

    //create spark session
    val spark = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()
    import spark.implicits._

    //Chargement des traceroutes sur un case class
    println("Chargement des traceroutes sur un case class")
    val rawtraceroutes = spark.read
      .schema(Encoders.product[Traceroute].schema)
      .json(dataPath)
      .as[Traceroute]

    println("Showing 10 rows of original Dataset")
    rawtraceroutes.show(10, truncate = false)
    
    println("Filter failed traceroutes ... ")
    val notFailedTraceroutes = rawtraceroutes.filter(x => x.result(0).result != null)
    
    //val maprtts = notFailedTraceroutes.map(x => removeNegative(x))

    
    
    
    

  }
}