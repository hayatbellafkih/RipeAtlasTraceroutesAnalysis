

package preparation

import org.apache.spark.sql.SparkSession
import java.util.{ Calendar, Date }
import java.util.Date
import java.text.SimpleDateFormat
import org.joda.time.{ DateTime, Period, DateTimeZone, LocalDateTime }
import org.joda.time.format.{ DateTimeFormatter, DateTimeFormat }
import org.apache.spark.sql.functions.unix_timestamp
import org.apache.spark.SparkContext
import java.time.ZonedDateTime
import org.apache.spark.SparkConf
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.apache.spark.SparkConf
import java.sql.Timestamp;
import org.apache.spark.sql.Encoders
import java.lang.Integer

import org.apache.commons.math3.stat.interval.WilsonScoreInterval
import org.apache.commons.math3.stat.interval.ConfidenceInterval

object PrepareTraceroutes_pre {

  var reference = LinkState(Seq(), Seq(), Seq(), Seq())
  var current = LinkState(Seq(), Seq(), Seq(), Seq())
  var alarms = Some()

  //case class
  case class Result(
    var result: Seq[Signal],
    hop:        Int)
  case class Signal(
    rtt:  Option[Double],
    x:    Option[String],
    from: Option[String])
  case class Traceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    result:    Seq[Result])

  case class ProceedSignal(
    medianRtt: Double,
    from:      String)
  case class ProceedResult(
    var result: Seq[ProceedSignal],
    hop:        Int)
  case class MedianByHopTraceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    result:    Seq[ProceedResult])

  case class Link(
    ip1:     String,
    ip2:     String,
    rttDiff: Double)
  case class LinksTraceroute(
    dst_name:  String,
    from:      String,
    prb_id:    BigInt,
    msm_id:    BigInt,
    timestamp: BigInt,
    links:     Seq[Link])

  case class LinkIPs(
    ip1: String,
    ip2: String)

  case class DiffRtt(
    rtt:      Double,
    var link: LinkIPs,
    probe:    BigInt
  //msm:   Map[BigInt, Seq[BigInt]]
  )
  case class DiffRTTPeriod(
    link:      LinkIPs,
    probes:    Seq[BigInt],
    rtts:      Seq[Double],
    var dates: Seq[Int])
  //var dates: Seq[java.time.LocalDateTime])

  case class TraceroutesPerPeriod(
    traceroutes: Seq[Traceroute],
    timeWindow:  Int)

  case class SampleDiffRTT(
    linksDetails: DiffRTTPeriod,
    period:       Date)
  def checkSignal(signal: Signal): Boolean = {
    if (signal.x == "*")
      return false
    else if (signal.rtt == None)
      return false
    else if (signal.rtt.get <= 0) {
      return false
    } else if (javatools.Tools.isPrivateIp(signal.from.get))
      return false
    else {
      return true
    }

  }
  def removeNegative(traceroute: Traceroute): Traceroute = {

    val outerList = traceroute.result
    for (temp <- outerList) {

      val hops = temp.result
      //here we are filtering the list to only contain nonnegative elements
      val newinnerList = hops.filter(checkSignal(_))
      //here we are reassigning the newlist to result
      temp.result = newinnerList

    }
    traceroute
  }

  def medianCalculator(seq: Seq[Double]): Double = {
    //In order if you are not sure that 'seq' is sorted
    val sortedSeq = seq.sortWith(_ < _)

    if (seq.size % 2 == 1) sortedSeq(sortedSeq.size / 2)
    else {
      val (up, down) = sortedSeq.splitAt(seq.size / 2)
      (up.last + down.head) / 2
    }
  }
  def getRtts(signals: Seq[Signal]): Seq[Double] = {
    val t = signals.map(f => f.rtt.get)
    return t
  }
  def findMedianFromSignals(hop: Result): ProceedResult = {

    val signals = hop.result
    val a = signals.groupBy(_.from.get)
    val c = a map { case (from, signaux) => from -> (getRtts(signaux)) }

    val b = c.map(f => ProceedSignal(medianCalculator(f._2), f._1))

    val d = b.toSeq
    return ProceedResult(d, hop.hop)

  }
  def computeMedianRTTByhop(traceroute: Traceroute): MedianByHopTraceroute = {
    val hops = traceroute.result
    val procHops = hops.map(f => findMedianFromSignals(f))

    return MedianByHopTraceroute(traceroute.dst_name, traceroute.from, traceroute.prb_id, traceroute.msm_id, traceroute.timestamp, procHops)

  }
  def findAllLinks(firstRouter: ProceedResult, nextRouter: ProceedResult): Seq[Link] = {
    var links = Seq[Link]()

    for (currentRouter <- firstRouter.result) {
      for (prochainouter <- nextRouter.result) {
        links = links :+ Link(currentRouter.from, prochainouter.from, (currentRouter.medianRtt - prochainouter.medianRtt))
      }
    }
    // println(links.toString())
    return links
  }
  def findLinksByTraceroute(spark: SparkSession, traceroute: MedianByHopTraceroute): LinksTraceroute = {
    val hops = traceroute.result
    val size = hops.size
    val s = hops.zipWithIndex
    val z = s.map {
      case (element, index) =>
        if (index + 1 < size) {
          findAllLinks(element, hops(index + 1))
        } else {
          null
        }
    }
    return new LinksTraceroute(traceroute.dst_name, traceroute.from, traceroute.prb_id, traceroute.msm_id, traceroute.timestamp, z.filter(p => p != null).flatten)
  }

  def resumeLinksTraceroute(traceroute: LinksTraceroute): Seq[DiffRtt] = {

    val links = traceroute.links
    val resumedLinks = links.map(f => DiffRtt(f.rttDiff, LinkIPs(f.ip1, f.ip2), traceroute.prb_id))
    resumedLinks
  }
  def sortLinks(diffRtt: DiffRtt): DiffRtt = {

    val link = Seq(diffRtt.link.ip1, diffRtt.link.ip2)
    val sortedLink = link.sorted

    diffRtt.link = LinkIPs(sortedLink(0), sortedLink(1))

    diffRtt
  }

  def splitStartEnd() {

  }
  def dateRange(start: DateTime, end: DateTime, step: Period): Iterator[DateTime] =
    Iterator.iterate(start)(_.plus(step)).takeWhile(!_.isAfter(end))

  def getTraceroutes(spark: SparkSession, startTimewindow: Int, endTimeWindow: Int): TraceroutesPerPeriod = {

    //val datasetTraceroute =
    val dataPath = getClass.getResource("/test/rttAnalysis_sample_5.json").getPath
    import spark.implicits._
    val rawtraceroutes = spark.read
      .schema(Encoders.product[Traceroute].schema)
      .json(dataPath)
      .as[Traceroute]

    println(rawtraceroutes.count())
    rawtraceroutes.toDF().show(100, truncate = false)
    val traceroutesPeriod = rawtraceroutes.filter(f => f.timestamp >= startTimewindow && f.timestamp < endTimeWindow)

    val f = traceroutesPeriod.collect().toSeq
    TraceroutesPerPeriod(f, startTimewindow)
  }

  //MAIN FUNCTION
  def main(args: Array[String]): Unit = {

    DateTimeZone.setDefault(DateTimeZone.UTC);
    val start = (new DateTime).withYear(2016)
      .withMonthOfYear(12)
      .withDayOfMonth(1)
      .withMinuteOfHour(0)
      .withHourOfDay(0)

    val end = (new DateTime).withYear(2016)
      .withMonthOfYear(12)
      .withDayOfMonth(25)
      .withMinuteOfHour(0)
      .withHourOfDay(0)
    //val rangeDates = dateRange(start, end, Period.hours(1))
    val rangeDates = Seq(1427847514, 1427849514, 1427857514)

    rangeDates.toSeq.foreach(println)

    val timewindow = 3600
    val timestamp = new Timestamp(start.getMillis()): Timestamp
    println("To timestam")
    println(timestamp)
    //val traceroutesPerPeriod = rangeDates.map(
    //  x => getTraceroutes(x, timewindow))

    main(start, end)

  }

  def dafcha(spark: SparkSession, rawtraceroutes: TraceroutesPerPeriod): Seq[DiffRTTPeriod] = {
    println("Showing 10 rows of original Dataset")

    println("Filter failed traceroutes ... ")
    val notFailedTraceroutes = rawtraceroutes.traceroutes.filter(x => x.result(0).result != null)

    println("Remove invalid data  in hops")
    val cleanedTraceroutes = notFailedTraceroutes.map(x => removeNegative(x))

    println("Showing 10 rows of cleaned dataset ...")
    //cleanedTraceroutes. show(10, truncate = false)

    println("Calcul de la mediane par hop (la mediane par source du signal) ...")
    val tracerouteMedianByHop = cleanedTraceroutes.map(x => computeMedianRTTByhop(x))
    //tracerouteMedianByHop.show(10, truncate = false)

    println("Inference des liens par traceroute ...")
    import org.apache.spark.mllib.rdd.RDDFunctions._
    val tracerouteLinks = tracerouteMedianByHop.map(f => findLinksByTraceroute(spark, f))
    //println(tracerouteLinks.show(10, truncate = false))

    val rttDiff = tracerouteLinks.map(resumeLinksTraceroute)
    val fllaten = rttDiff.flatten

    // val finalresult = fllaten.show(100, truncate = false)

    val sorted = fllaten.map(f => sortLinks(f))
    // sorted.toSeq.toDF().show(100, truncate = false)

    val mergedData = sorted.groupBy(_.link)
    //println( mergedData.toString())

    val resumeData = mergedData.map(f => DiffRTTPeriod(f._1, f._2.map(_.probe), f._2.map(_.rtt), generateDatesSample(f._2.size, rawtraceroutes.timeWindow)))
    // resumeData.toSeq.toDF().show(100, truncate = false)

    resumeData.toSeq
  }
  case class LinkState(
    var valueMedian: Seq[Double],
    var valueHi:     Seq[Double],
    var valueLow:    Seq[Double],
    var valueMean:   Seq[Double])

  def findAlarms(spark: SparkSession, date: Int, reference: LinkState, dataPeriod: DiffRTTPeriod): Unit = {
    println("######################### Analysis for date" + date + " ######################")
    println("Find indices ...")
    val indices = dataPeriod.dates.zipWithIndex.filter(_._1 == date).map(_._2)

    println("Indices :" + indices.toString())
    val dist = indices.map(f => dataPeriod.rtts(f))

    println("Find RTTs for the current timewindow ...")
    val distSize = dist.size
    val wilsonCi = scoreWilsonScoreCalculator(spark, dist.size).map(f => f * dist.size)

    println("Before " + current.toString())
    updateLinkCurrentState(spark, dist, current, wilsonCi)
    println("After " + current.toString())
    /*
    if (reference.valueMedian.size < 24) {
      reference.valueMedian :+ current.valueMedian.last
      reference.valueHi :+ dist(javatools.JavaTools.getIntegerPart(wilsonCi(1)))
      reference.valueLow :+ dist(javatools.JavaTools.getIntegerPart(wilsonCi(0)))
    } else if (reference.valueMedian.size == 24) {

      reference.valueMedian :+ medianCalculator(reference.valueMedian)
      reference.valueHi :+ medianCalculator(reference.valueHi)
      reference.valueLow :+ medianCalculator(reference.valueLow)

      val newReferenceValueAVg = reference.valueMedian.map(f => reference.valueMedian.last)
      reference.valueMedian = newReferenceValueAVg
      val newReferenceValueHi = reference.valueHi.map(f => reference.valueHi.last)
      reference.valueHi = newReferenceValueHi

      val newReferenceValueLow = reference.valueLow.map(f => reference.valueLow.last)
      reference.valueLow = newReferenceValueLow
    } else {
      reference.valueMedian :+ (0.99 * reference.valueMedian.last + 0.01* current.valueMedian.last)
      reference.valueHi :+ (0.99 * reference.valueHi.last + 0.01* dist(javatools.JavaTools.getIntegerPart(wilsonCi(1))))
      reference.valueLow :+ (0.99 * reference.valueLow.last + 0.01* dist(javatools.JavaTools.getIntegerPart(wilsonCi(0))))
    }
    *
    */
  }

  def updateLinkCurrentState(spark: SparkSession, dist: Seq[Double], current: LinkState, wilsonCi: Seq[Double]) {
    val median = medianCalculator(dist)
    val newDist = dist.sorted

    println(current.toString())
    val tmp = current
    val newValueMedian = tmp.valueMedian :+ median
    current.valueMedian = newValueMedian

    val newValueHi = tmp.valueLow :+ (tmp.valueMedian.last - newDist(javatools.JavaTools.getIntegerPart(wilsonCi(0))))
    val newValueLow = tmp.valueHi :+ (newDist(javatools.JavaTools.getIntegerPart(wilsonCi(1)))) - current.valueMedian.last

    current.valueHi = newValueHi
    current.valueLow = newValueLow

    println("Current state link")
    println(current.toString())

  }

  def scoreWilsonScoreCalculator(spark: SparkSession, distSize: Int): Seq[Double] = {
    val sqlContext = spark.sqlContext
    val score = new WilsonScoreInterval().createInterval(distSize, distSize / 2, 0.95)
    Seq(score.getLowerBound, score.getUpperBound)
  }
  def generateDatesSample(size: Int, date: Int): Seq[Int] = {
    //val mydate=
    // val x = java.time.LocalDateTime.ofEpochSecond(date,0,java.time.ZoneOffset.UTC)
    List.tabulate(size)(n => date).toSeq

  }

  def convertUnixTimeStampToDate(timestamp: Int): java.time.LocalDateTime = {
    val x = java.time.LocalDateTime.ofEpochSecond(timestamp, 0, java.time.ZoneOffset.UTC)
    x
  }
  def updateDates() {

  }
  def main(startTimeWindow: DateTime, endTimeWindow: DateTime): Unit = {
    implicit val localDateOrdering: Ordering[java.time.LocalDateTime] = Ordering.by(_.toEpochSecond(java.time.ZoneOffset.UTC))

    println("Préparation des traceroutes ...")

    //Create configuration
    val conf = new SparkConf().setAppName("RTT delays analysis").setMaster("local")

    //trouver le chemin vers les donnees
    val dataPath = getClass.getResource("/test/rttAnalysis_sample_5.json").getPath

    //create spark session
    val spark = SparkSession
      .builder()
      .config(conf)
      .getOrCreate()
    import spark.implicits._

    //Chargement des traceroutes sur un case class
    println("Chargement des traceroutes sur un case class")
    val rawtraceroutes = spark.read
      .schema(Encoders.product[Traceroute].schema)
      .json(dataPath)
      .as[Traceroute]

    //Divise traceroutes per period

    val rangeDates = Seq(1514769809, 1514773409, 1514777009, 1514780609, 1514784209)
    val timewindow = 3600
    val rangeDatesTimewindows = rangeDates.map(f => (f, f + timewindow))

    val traceroutesPerPeriod = rangeDatesTimewindows.map(f => getTraceroutes(spark, f._1, f._2))

    traceroutesPerPeriod.toDF().show(100, truncate = false)

    val dafchad = traceroutesPerPeriod.map(f => dafcha(spark, f))

    dafchad.foreach(f => f.toDF().show(100, truncate = false))

    val collectedRTTDiff = dafchad.flatten
    collectedRTTDiff.toDF().show(100, truncate = false)

    val finalResult = collectedRTTDiff.groupBy(_.link)
    val finalRawRttDiff = finalResult.map(f => DiffRTTPeriod(f._1, (f._2.map(_.probes)).flatten, (f._2.map(_.rtts)).flatten, (f._2.map(_.dates)).flatten))

    finalRawRttDiff.toSeq.toDF().show(100, truncate = false)

    val rawDataLinkFiltred = finalRawRttDiff.filter(p => p.link.ip1 == "185.147.12.19" && p.link.ip2 == "185.147.12.31").toSeq

    if (rawDataLinkFiltred.size == 0) System.exit(0)
    val rawDataLink = rawDataLinkFiltred(0)
    println(rawDataLink.toString())

    //val datee= rawDataLink.dates)

    val start = rawDataLink.dates.min
    val end = rawDataLink.dates.max + 86400

    //val x = java.time.LocalDateTime.ofEpochSecond(start,0,java.time.ZoneOffset.UTC)
    //val xx = java.time.LocalDateTime.ofEpochSecond(end,0,java.time.ZoneOffset.UTC).plusDays(1)

    //val minDate= rawDataLink.dates.stream().min(java.time.LocalDateTime::compareTo)

    val datesEvolution = start.to(end).by(timewindow)

    println(datesEvolution)

    //val tmp= rawDataLink.dates.map(f =>java.time.LocalDateTime.ofEpochSecond(f,0,java.time.ZoneOffset.UTC) )

    // rawDataLink.dates = tmp

    //FIND ALARMS
    datesEvolution.foreach(f => findAlarms(spark, f, reference, rawDataLink))

    //val indexRtts = datesEvolution.map(f => findAlarms(spark, f, null, rawDataLink))

    //val dist = indexRtts.map(f=> rawDataLink.rtts(f))

    //val x = java.time.LocalDateTime.ofEpochSecond(1511393354,0,java.time.ZoneOffset.UTC)

    //println(x) OK :)
    // val kk=DateTime.parse(formattedDate, )

    //val test1= test.toSeq
    //val test2 = test1(0).dates.groupBy(f)

    // test2
    //dafchad(0).toDF().show(100, truncate=false)

    //val q= dafchad.map(f => f.map(ff => updateDates(f.)))

    //val traceroutesPerPeriod = rawtraceroutes.filter(x => x.timestamp > startTimewindow && x.timestamp < endTimewindow)
    //val rawtraceroutesPerPeriod =rawtrfuncaceroutes.map(func, encoder)

    // traceroutesPerPeriod.map(f)
    //    println("Showing 10 rows of original Dataset")
    //    rawtraceroutes.show(10, truncate = false)
    //
    //    println("Filter failed traceroutes ... ")
    //    val notFailedTraceroutes = rawtraceroutes.filter(x => x.result(0).result != null)
    //
    //    println("Remove invalid data  in hops")
    //    val cleanedTraceroutes = notFailedTraceroutes.map(x => removeNegative(x))
    //
    //    println("Showing 10 rows of cleaned dataset ...")
    //    cleanedTraceroutes.show(10, truncate = false)
    //
    //    println("Calcul de la mediane par hop (la mediane par source du signal) ...")
    //    val tracerouteMedianByHop = cleanedTraceroutes.map(x => computeMedianRTTByhop(x))
    //    tracerouteMedianByHop.show(10, truncate = false)
    //
    //    println("Inference des liens par traceroute ...")
    //    import org.apache.spark.mllib.rdd.RDDFunctions._
    //    val tracerouteLinks = tracerouteMedianByHop.map(f => findLinksByTraceroute(spark, f))
    //    println(tracerouteLinks.show(10, truncate = false))
    //
    //    val rttDiff = tracerouteLinks.map(resumeLinksTraceroute)
    //    val fllaten = rttDiff.collect().flatten
    //
    //    val finalresult = fllaten.toSeq.toDF().show(100, truncate = false)
    //
    //    val sorted = fllaten.map(f => sortLinks(f))
    //    sorted.toSeq.toDF().show(100, truncate = false)
    //
    //    val mergedData = sorted.groupBy(_.link)
    //    //println( mergedData.toString())
    //
    //    val resumeData = mergedData.map(f => DiffRTTPeriod(f._1, f._2.map(_.probe), f._2.map(_.rtt)))
    //    resumeData.toSeq.toDF().show(100, truncate = false)

  }
}