package javatools;

public class JavaTools {

	public static int  getIntegerPart(double value) {
		int d = (int) value;
		return d;
	}
}
